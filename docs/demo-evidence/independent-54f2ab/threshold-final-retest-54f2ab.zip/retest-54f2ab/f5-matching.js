async page => {
 const results=[];
 for(const width of [1440,390,320]){
 await page.setViewportSize({width,height:width===1440?1000:844});
 const week=page.getByText(width===1440?'Oct 5 – Oct 11':'Oct 5 wk',{exact:true});
 const summary=async()=>await week.evaluate(e=>e.parentElement.innerText);
 const before=await summary(); await week.scrollIntoViewIfNeeded();
 if(width===320)await page.screenshot({path:'output/playwright/retest-54f2ab/03-unlinked-elevation-320.png'});
 await page.getByRole('button',{name:/Steady trail run RUN/}).click(); await page.getByRole('dialog').waitFor();
 await page.getByRole('combobox',{name:'Choose an imported activity',exact:true}).selectOption({label:'2026-10-07 · Ridge exploration · 60 min'});
 await page.getByRole('button',{name:'Confirm activity match',exact:true}).click();
 const matchedDetail=await page.getByRole('dialog').ariaSnapshot();
 await page.getByRole('button',{name:'Confirm activity match',exact:true}).click(); await page.getByRole('button',{name:'Close',exact:true}).click();
 const linked=await summary(); await week.scrollIntoViewIfNeeded();
 await page.screenshot({path:'output/playwright/retest-54f2ab/04-linked-elevation-'+width+'.png'});
 await page.reload(); await page.getByRole('heading',{name:'Training Calendar',exact:true,level:1}).waitFor(); const reloaded=await summary();
 await page.getByRole('button',{name:/Steady trail run RUN/}).click(); await page.getByRole('dialog').waitFor(); await page.getByRole('button',{name:'Unlink activity',exact:true}).click(); await page.getByRole('button',{name:'Close',exact:true}).click(); const unlinked=await summary();
 results.push({at:new Date().toISOString(),width,before,matchedDetail,linked,reloaded,unlinked});
 }
 return results;
}
