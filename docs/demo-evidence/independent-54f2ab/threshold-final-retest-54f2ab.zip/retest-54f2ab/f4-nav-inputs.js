async page => {
 const results=[];
 for(const width of [1440,390,320]){
 await page.setViewportSize({width,height:width===1440?1000:844});
 await page.getByRole('button',{name:'Today',exact:true}).first().click(); await page.getByRole('heading',{name:'Today',exact:true,level:1}).waitFor();
 await page.getByRole('button',{name:/2026-10-09 .*Steady trail/}).click(); await page.getByRole('dialog').waitFor();
 const steadyUrl=page.url();
 await page.getByRole('spinbutton',{name:'Actual duration in minutes',exact:true}).fill('111'); await page.getByRole('textbox',{name:'Workout notes',exact:true}).fill('Synthetic unsaved Steady draft');
 await page.getByRole('button',{name:'Close',exact:true}).click(); const closeUrl=page.url();
 await page.getByRole('button',{name:/Recovery run RUN/}).click(); await page.getByRole('dialog').waitFor(); const recoveryUrl=page.url();
 const selected={url:recoveryUrl,heading:await page.getByRole('dialog').getByRole('heading').innerText(),duration:await page.getByRole('spinbutton',{name:'Actual duration in minutes',exact:true}).inputValue(),notes:await page.getByRole('textbox',{name:'Workout notes',exact:true}).inputValue()};
 if(width===320){await page.getByRole('dialog').evaluate(d=>d.scrollTop=0);await page.screenshot({path:'output/playwright/retest-54f2ab/01-recovery-before-refresh-320.png'});}
 await page.reload(); await page.getByRole('dialog').waitFor(); const refreshed={url:page.url(),heading:await page.getByRole('dialog').getByRole('heading').innerText()};
 if(width===320){await page.getByRole('dialog').evaluate(d=>d.scrollTop=0);await page.screenshot({path:'output/playwright/retest-54f2ab/02-recovery-after-refresh-320.png'});}
 await page.getByRole('spinbutton',{name:'Actual duration in minutes',exact:true}).fill('222'); await page.getByRole('textbox',{name:'Workout notes',exact:true}).fill('Synthetic unsaved Recovery draft'); await page.getByRole('textbox',{name:'Write a comment',exact:true}).fill('Synthetic unsent Recovery comment');
 await page.goto(steadyUrl); await page.getByRole('heading',{name:'Steady trail run',exact:true,level:3}).waitFor();
 const switchSteady={duration:await page.getByRole('spinbutton',{name:'Actual duration in minutes',exact:true}).inputValue(),notes:await page.getByRole('textbox',{name:'Workout notes',exact:true}).inputValue(),comment:await page.getByRole('textbox',{name:'Write a comment',exact:true}).inputValue()};
 await page.getByRole('spinbutton',{name:'Actual duration in minutes',exact:true}).fill('333'); await page.goto(recoveryUrl); await page.getByRole('heading',{name:'Recovery run',exact:true,level:3}).waitFor();
 const switchBack=await page.getByRole('spinbutton',{name:'Actual duration in minutes',exact:true}).inputValue(); await page.getByRole('button',{name:'Close',exact:true}).click(); const finalClose=page.url(); await page.reload(); await page.getByRole('heading',{name:'Training Calendar',exact:true,level:1}).waitFor();
 results.push({at:new Date().toISOString(),width,steadyUrl,closeUrl,selected,refreshed,switchSteady,switchBack,finalClose,dialogsAfterCloseReload:await page.getByRole('dialog').count()});
 }
 return results;
}
