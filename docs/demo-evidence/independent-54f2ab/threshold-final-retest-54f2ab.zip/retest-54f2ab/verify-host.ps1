$base='https://ultra-os-tb77-fbct852gc-tadschweizers-projects.vercel.app'
$assets=@('index.html','assets/index-BQKfX-nn.js','assets/index-BixaqdIL.css','favicon.svg')
$results=@()
foreach($asset in $assets){
  $dest=Join-Path $PSScriptRoot ([IO.Path]::GetFileName($asset))
  Invoke-WebRequest -UseBasicParsing ($base+'/'+$asset) -OutFile $dest
  $results += [pscustomobject]@{file=$asset;bytes=(Get-Item -LiteralPath $dest).Length;sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $dest).Hash.ToLower()}
}
$paths=@('/api/planned-workouts','/api/coach/messages','/api/message-drafts','/api/admin/demo','/api/workout-export?id=synthetic-qa')
$probes=@()
foreach($path in $paths){
  try { $r=Invoke-WebRequest -UseBasicParsing ($base+$path); $status=[int]$r.StatusCode }
  catch { $status=[int]$_.Exception.Response.StatusCode }
  $probes += [pscustomobject]@{method='GET';path=$path;status=$status}
}
$record=[pscustomobject]@{timestamp=(Get-Date).ToUniversalTime().ToString('o');url=$base;assets=$results;csp=(Invoke-WebRequest -UseBasicParsing $base).Headers['Content-Security-Policy'];staticHostProbes=$probes}
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'host-evidence.json')
$record | ConvertTo-Json -Depth 8

